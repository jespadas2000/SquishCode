#pragma once
#include <qtreeview.h>
#include "APP_personItem.h"

#define REAL_COLUMN_NUMBER 5
#define VIEW_COLUMN_NUMBER 2

class APP_personModelTree : public QAbstractItemModel
{
	Q_OBJECT

public:
    Q_DISABLE_COPY_MOVE(APP_personModelTree)

    explicit APP_personModelTree(const QStringList& data, QObject* parent = nullptr);
    ~APP_personModelTree() override;

    QVariant data(const QModelIndex& index, int role) const override;
    Qt::ItemFlags flags(const QModelIndex& index) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
        int role = Qt::DisplayRole) const override;
    QModelIndex index(int row, int column,
        const QModelIndex& parent = {}) const override;
    QModelIndex parent(const QModelIndex& index) const override;
    int rowCount(const QModelIndex& parent = {}) const override;
    int columnCount(const QModelIndex& parent = {}) const override;
    void addItem(APP_personItem* newPerson);
    APP_personItem* searchItem(QString parent, APP_personItem* root);
    QStringList personList();

private:
    static void setupModelData(const QList<QStringView>& lines, APP_personModelTree* parent);
    QStringList allPerson(APP_personItem* root);

    APP_personItem m_rootItem;
};

