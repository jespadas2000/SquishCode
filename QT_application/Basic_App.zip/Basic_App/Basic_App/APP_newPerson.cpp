#include "APP_newPerson.h"

APP_newPerson::APP_newPerson(QStringList parents, QWidget* parent)
{
	m_ui.setupUi(this);
	setWindowTitle("New Person");

	m_pNameValidator = new APP_nameValidator();
	m_ui.m_nameQLine->setValidator(m_pNameValidator);
	m_ui.m_surnameQLine->setValidator(m_pNameValidator); 
	m_pAgeValidator = new APP_ageValidator();
	m_ui.m_ageQLine->setValidator(m_pAgeValidator);

	m_ui.m_sexComboBox->addItem("");
	m_ui.m_sexComboBox->addItem("Male");
	m_ui.m_sexComboBox->addItem("Woman");
	m_ui.m_sexComboBox->addItem("Other");

	m_ui.m_parentComboBox->addItem("No parent");
	m_ui.m_parentComboBox->addItems(parents);

	connect(m_ui.m_okButton, SIGNAL(clicked()), this, SLOT(okButtonSlot()));
	connect(m_ui.m_cancelButton, SIGNAL(clicked()), this, SLOT(cancelButtonSlot()));
}

void APP_newPerson::cancelButtonSlot()
{
	reject();
}

void APP_newPerson::okButtonSlot()
{
	if (m_ui.m_nameQLine->text() != "" && m_ui.m_surnameQLine->text() != "" && m_ui.m_ageQLine->text() != "" && m_ui.m_sexComboBox->currentText() !="")
	{
		accept();
	}
	else
	{
		QMessageBox::information(this, "Error", "To add a person please fill all the empty boxes", QMessageBox::Ok, QMessageBox::Ok);
	}
}


QString APP_newPerson::getName()
{
	return m_ui.m_nameQLine->text();
}

QString APP_newPerson::getSurName()
{
	return m_ui.m_surnameQLine->text();
}

QString APP_newPerson::getAge()
{
	return m_ui.m_ageQLine->text();
}

QString APP_newPerson::getSex()
{
	if(m_ui.m_sexComboBox->currentText() == "Male")
	{
		return "M";
	}
	if (m_ui.m_sexComboBox->currentText() == "Woman")
	{
		return "W";
	}
	if (m_ui.m_sexComboBox->currentText() == "Other")
	{
		return "O";
	}
	return "Error";
}

QString APP_newPerson::getParent()
{
	return m_ui.m_parentComboBox->currentText();
}