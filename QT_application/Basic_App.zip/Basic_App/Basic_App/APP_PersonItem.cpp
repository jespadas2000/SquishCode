#include "APP_personItem.h"

APP_personItem::APP_personItem(QStringList data, bool root, APP_personItem* parent)
    : m_itemData(std::move(data)), m_parentItem(parent)
{
    m_boolRoot = root;
}

void APP_personItem::appendChild(APP_personItem* child)
{
    m_childItems.append(child);
    child->setParent(this);
}

APP_personItem* APP_personItem::child(int row) const
{

    return m_childItems.at(row);
}

int APP_personItem::childCount() const
{
    return int(m_childItems.size());
}

int APP_personItem::row() const
{
    if (m_parentItem != nullptr)
    {
        for(int i=0 ; m_parentItem->childCount()>i ; i++)
        {
            m_parentItem->child(i);
            if (m_parentItem->child(i)->data(PERSON_COLUMN_NAME) == this->data(PERSON_COLUMN_NAME) && m_parentItem->child(i)->data(PERSON_COLUMN_SURNAME) == this->data(PERSON_COLUMN_SURNAME))
            {
                return i;
            }
        }
    }
    return 0;
}

int APP_personItem::columnCount() const
{
    return int(m_itemData.count());
}

QVariant APP_personItem::data(int column) const
{
    return m_itemData.value(column);
}

APP_personItem* APP_personItem::parentItem()
{
    if (m_boolRoot)
    {
        return nullptr;
    }
    return m_parentItem;
}

bool APP_personItem::rootPerson()
{
    return m_boolRoot;
}

void APP_personItem::setParent(APP_personItem* newParent)
{
    m_parentItem = newParent;
}