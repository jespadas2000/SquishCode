#include "APP_personModelTree.h"

APP_personModelTree::APP_personModelTree(const QStringList& data, QObject* parent)
    : QAbstractItemModel(parent)
    , m_rootItem(data, true)
{}

APP_personModelTree::~APP_personModelTree() = default;

QModelIndex APP_personModelTree::index(int row, int column, const QModelIndex& parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    if (parent.isValid())
    {
        APP_personItem* parentItem = static_cast<APP_personItem*>(parent.internalPointer());
        if (auto* childItem = parentItem->child(row))
            return createIndex(row, column, childItem);
    }
    else
    {
        if (auto* childItem = m_rootItem.child(row))
            return createIndex(row, column, childItem);
    }
    return QModelIndex();
}

QModelIndex APP_personModelTree::parent(const QModelIndex& index) const
{
    if (!index.isValid())
        return QModelIndex();

    auto* childItem = static_cast<APP_personItem*>(index.internalPointer());
    APP_personItem* parentItem = childItem->parentItem();

    if (parentItem->rootPerson())
    {
        return QModelIndex();
    }
    else
    {
        return createIndex(parentItem->row(), 0, parentItem);
    }
}

int APP_personModelTree::rowCount(const QModelIndex& parent) const
{
    if (parent.column() > 0)
        return 0;

    if (parent.isValid())
    {
        APP_personItem* parentItem = static_cast<APP_personItem*>(parent.internalPointer());
        return parentItem->childCount();
    }
    else
    {
        return m_rootItem.childCount();
    }
}

int APP_personModelTree::columnCount(const QModelIndex& parent) const
{
    if (parent.isValid())
        return static_cast<APP_personItem*>(parent.internalPointer())->columnCount();
    return m_rootItem.columnCount();
}

QVariant APP_personModelTree::data(const QModelIndex& index, int role) const
{
    if (!index.isValid())
        return {};

    auto* selectedPerson = static_cast<const APP_personItem*>(index.internalPointer());
    if (role == Qt::DisplayRole)
    {
        //const auto* item = static_cast<const APP_personItem*>(index.internalPointer());
        //return item->data(index.column());
        if (index.column() == PERSON_COLUMN_NAME)
        {
            return selectedPerson->data(PERSON_COLUMN_NAME);
        }
        if (index.column() == PERSON_COLUMN_SURNAME)
        {
            return selectedPerson->data(PERSON_COLUMN_SURNAME);
        }
        if (index.column() == PERSON_COLUMN_AGE)
        {
            return selectedPerson->data(PERSON_COLUMN_AGE);
        }
        if (index.column() == PERSON_COLUMN_SEX)
        {
           return selectedPerson->data(PERSON_COLUMN_SEX);
        }
        if (index.column() == COLUMN_COLUMN_PARENT)
        {
           return selectedPerson->data(COLUMN_COLUMN_PARENT);
        }
    }
   
    return {};
}

Qt::ItemFlags APP_personModelTree::flags(const QModelIndex& index) const
{
    return index.isValid()
        ? QAbstractItemModel::flags(index) : Qt::ItemFlags(Qt::NoItemFlags);
}

QVariant APP_personModelTree::headerData(int section, Qt::Orientation orientation,
    int role) const
{
    return orientation == Qt::Horizontal && role == Qt::DisplayRole
        ? m_rootItem.data(section) : QVariant{};
}

void APP_personModelTree::addItem(APP_personItem* newPerson)
{
    beginInsertRows(QModelIndex(), m_rootItem.childCount(), m_rootItem.childCount() + 1);
    if ("No parent" == newPerson->data(COLUMN_COLUMN_PARENT).toString())
    {
        m_rootItem.appendChild(newPerson);
    }
    else
    {
        APP_personItem* parent = searchItem(newPerson->data(COLUMN_COLUMN_PARENT).toString(), &m_rootItem);

        if (parent != nullptr)
        {
            parent->appendChild(newPerson);
        }
    }
    endInsertRows();
}

APP_personItem* APP_personModelTree::searchItem(QString parent, APP_personItem* root)
{
    APP_personItem* localPerson;
    QStringList nameSurName = parent.split(" ");
    QString name = nameSurName.at(0);
    QString surName = nameSurName.at(1);
    for(int i=0;i<root->childCount();i++)
    {
        localPerson = root->child(i);

        if (localPerson->data(PERSON_COLUMN_NAME).toString() == name && localPerson->data(PERSON_COLUMN_SURNAME).toString() == surName)
        {
            return localPerson;
        }
        else if (localPerson->childCount() > 0)
        {
            localPerson = searchItem(parent, localPerson);
            if (localPerson != nullptr)
            {
                return localPerson;
            }
        }
    }
    return nullptr;
   
}

QStringList APP_personModelTree::personList()
{
    return allPerson(&m_rootItem);
}

QStringList APP_personModelTree::allPerson(APP_personItem* root)
{
      QStringList personsList;
      APP_personItem* person;

      for(int i = 0; i< root->childCount(); i++)
      {
          person = root->child(i);
          personsList.append(person->data(PERSON_COLUMN_NAME).toString()+" "+person->data(PERSON_COLUMN_SURNAME).toString());
          if (person->childCount() > 0)
          {
              personsList.append(allPerson(person));
          }
      }

      return personsList;
}