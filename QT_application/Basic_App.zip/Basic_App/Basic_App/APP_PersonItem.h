#include <qvariant.h>
#include <qvector.h>

#define PERSON_COLUMN_NAME 0
#define PERSON_COLUMN_SURNAME 1
#define PERSON_COLUMN_AGE 2
#define PERSON_COLUMN_SEX 3
#define COLUMN_COLUMN_PARENT 4


class APP_personItem
{
public:
    explicit APP_personItem(QStringList data, bool root=false, APP_personItem* parentItem = nullptr);

    void appendChild(APP_personItem* child);

    APP_personItem* child(int row) const;
    int childCount() const;
    int columnCount() const;
    QVariant data(int column) const;
    int row() const;
    APP_personItem* parentItem();
    bool rootPerson();
    void setParent(APP_personItem* newParent);

private:
    QList<APP_personItem*> m_childItems;
    QStringList m_itemData;
    APP_personItem* m_parentItem;
    bool m_boolRoot;
};
