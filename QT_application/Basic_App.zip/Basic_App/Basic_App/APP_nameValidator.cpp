#include "APP_nameValidator.h"

QValidator::State APP_nameValidator::validate(QString& input, int& pos) const
{
	if (pos == 0) { //avoid erros whit 'delete' when the 'lineEdit' is empty.
		return  Acceptable;
	}
	if (input.at(pos - 1).digitValue() != -1) {// no numbers allowed 
		return Invalid;
	}
	return  Acceptable;
}