/********************************************************************************
** Form generated from reading UI file 'APP_newPerson.ui'
**
** Created by: Qt User Interface Compiler version 6.2.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APP_NEWPERSON_H
#define UI_APP_NEWPERSON_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_APP_newPersonClass
{
public:
    QGridLayout *gridLayout;
    QLabel *m_surnameLabel;
    QLabel *m_sexLabel;
    QLabel *m_parentLabel;
    QPushButton *m_cancelButton;
    QPushButton *m_okButton;
    QLineEdit *m_nameQLine;
    QComboBox *m_parentComboBox;
    QLabel *m_nameLabel;
    QComboBox *m_sexComboBox;
    QLabel *m_ageLabel;
    QLineEdit *m_surnameQLine;
    QLineEdit *m_ageQLine;

    void setupUi(QDialog *APP_newPersonClass)
    {
        if (APP_newPersonClass->objectName().isEmpty())
            APP_newPersonClass->setObjectName(QString::fromUtf8("APP_newPersonClass"));
        APP_newPersonClass->resize(252, 184);
        gridLayout = new QGridLayout(APP_newPersonClass);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        m_surnameLabel = new QLabel(APP_newPersonClass);
        m_surnameLabel->setObjectName(QString::fromUtf8("m_surnameLabel"));

        gridLayout->addWidget(m_surnameLabel, 1, 0, 1, 1);

        m_sexLabel = new QLabel(APP_newPersonClass);
        m_sexLabel->setObjectName(QString::fromUtf8("m_sexLabel"));

        gridLayout->addWidget(m_sexLabel, 3, 0, 1, 1);

        m_parentLabel = new QLabel(APP_newPersonClass);
        m_parentLabel->setObjectName(QString::fromUtf8("m_parentLabel"));

        gridLayout->addWidget(m_parentLabel, 4, 0, 1, 1);

        m_cancelButton = new QPushButton(APP_newPersonClass);
        m_cancelButton->setObjectName(QString::fromUtf8("m_cancelButton"));

        gridLayout->addWidget(m_cancelButton, 6, 2, 1, 1);

        m_okButton = new QPushButton(APP_newPersonClass);
        m_okButton->setObjectName(QString::fromUtf8("m_okButton"));

        gridLayout->addWidget(m_okButton, 6, 1, 1, 1);

        m_nameQLine = new QLineEdit(APP_newPersonClass);
        m_nameQLine->setObjectName(QString::fromUtf8("m_nameQLine"));

        gridLayout->addWidget(m_nameQLine, 0, 1, 1, 2);

        m_parentComboBox = new QComboBox(APP_newPersonClass);
        m_parentComboBox->setObjectName(QString::fromUtf8("m_parentComboBox"));

        gridLayout->addWidget(m_parentComboBox, 4, 1, 1, 2);

        m_nameLabel = new QLabel(APP_newPersonClass);
        m_nameLabel->setObjectName(QString::fromUtf8("m_nameLabel"));

        gridLayout->addWidget(m_nameLabel, 0, 0, 1, 1);

        m_sexComboBox = new QComboBox(APP_newPersonClass);
        m_sexComboBox->setObjectName(QString::fromUtf8("m_sexComboBox"));

        gridLayout->addWidget(m_sexComboBox, 3, 1, 1, 2);

        m_ageLabel = new QLabel(APP_newPersonClass);
        m_ageLabel->setObjectName(QString::fromUtf8("m_ageLabel"));

        gridLayout->addWidget(m_ageLabel, 2, 0, 1, 1);

        m_surnameQLine = new QLineEdit(APP_newPersonClass);
        m_surnameQLine->setObjectName(QString::fromUtf8("m_surnameQLine"));

        gridLayout->addWidget(m_surnameQLine, 1, 1, 1, 2);

        m_ageQLine = new QLineEdit(APP_newPersonClass);
        m_ageQLine->setObjectName(QString::fromUtf8("m_ageQLine"));

        gridLayout->addWidget(m_ageQLine, 2, 1, 1, 2);


        retranslateUi(APP_newPersonClass);

        QMetaObject::connectSlotsByName(APP_newPersonClass);
    } // setupUi

    void retranslateUi(QDialog *APP_newPersonClass)
    {
        APP_newPersonClass->setWindowTitle(QCoreApplication::translate("APP_newPersonClass", "Dialog", nullptr));
        m_surnameLabel->setText(QCoreApplication::translate("APP_newPersonClass", "Surname:", nullptr));
        m_sexLabel->setText(QCoreApplication::translate("APP_newPersonClass", "Sex:", nullptr));
        m_parentLabel->setText(QCoreApplication::translate("APP_newPersonClass", "Parent:", nullptr));
        m_cancelButton->setText(QCoreApplication::translate("APP_newPersonClass", "Cancel", nullptr));
        m_okButton->setText(QCoreApplication::translate("APP_newPersonClass", "OK", nullptr));
        m_nameLabel->setText(QCoreApplication::translate("APP_newPersonClass", "Name:", nullptr));
        m_ageLabel->setText(QCoreApplication::translate("APP_newPersonClass", "Age:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class APP_newPersonClass: public Ui_APP_newPersonClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APP_NEWPERSON_H
