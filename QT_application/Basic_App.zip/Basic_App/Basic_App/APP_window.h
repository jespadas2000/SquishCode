#pragma once
#include "ui_APP_window.h"
#include "APP_personModelTree.h"
#include "APP_newPerson.h"
#include <QtWidgets/QMainWindow>
#include <qwidget.h>

class APP_window : public QMainWindow
{
    Q_OBJECT
protected:
    Ui::APP_windowClass m_ui;

public:
    APP_window(QWidget* pParent = Q_NULLPTR);
    virtual ~APP_window();

protected:
    APP_personModelTree *m_pTreeModel;

protected slots:
    void newPersonButtonSlot();
    void selectedPersonSlot(const QModelIndex selectedPerson);
    void exitPersonButtonSlot();
};

