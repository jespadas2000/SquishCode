#include "APP_window.h"

APP_window::APP_window(QWidget* parent) : QMainWindow(parent)
{
	m_ui.setupUi(this);
	setWindowTitle("Person Tree");

	m_pTreeModel = new APP_personModelTree({"Name", "Surname", "Age", "Sex", "Parent" });
	m_ui.m_personTreeView->setModel(m_pTreeModel);
	m_ui.m_personTreeView->setColumnHidden(2, true);
	m_ui.m_personTreeView->setColumnHidden(3, true);
	m_ui.m_personTreeView->setColumnHidden(4, true);

	connect(m_ui.m_newPersonButton, SIGNAL(clicked()), this, SLOT(newPersonButtonSlot()));
	connect(m_ui.m_personTreeView, SIGNAL(clicked(const QModelIndex)), this, SLOT(selectedPersonSlot(const QModelIndex)));
	connect(m_ui.m_exitButton, SIGNAL(clicked()), this, SLOT(exitPersonButtonSlot()));

	m_pTreeModel->addItem(new APP_personItem({ "Pedro", "Gutierrez", "23", "M", "No parent" }));
	m_pTreeModel->addItem(new APP_personItem({ "Sara", "Martinez", "47", "W", "No parent" }));
	m_pTreeModel->addItem(new APP_personItem({ "Marta", "Zarraute", "31", "W", "No parent" }));
	m_pTreeModel->addItem(new APP_personItem({ "Roman", "Fernandez", "15", "M", "Sara Martinez" }));
	//m_pTreeModel
}

APP_window::~APP_window()
{
	if (m_pTreeModel)
	{
		delete m_pTreeModel;
		m_pTreeModel = NULL;
	}
}

void APP_window::newPersonButtonSlot()
{
	APP_newPerson* newPersonDialog = new APP_newPerson(m_pTreeModel->personList(), this);
	if (newPersonDialog->exec() == QDialog::Accepted)
	{
		m_pTreeModel->addItem(new APP_personItem({ newPersonDialog->getName(), newPersonDialog->getSurName(), newPersonDialog->getAge(), newPersonDialog->getSex(), newPersonDialog->getParent()}));
	}
}

void APP_window::selectedPersonSlot(const QModelIndex selectedPerson)
{
	m_ui.m_personListWidget->clear();
	auto* Person = static_cast<const APP_personItem*>(selectedPerson.internalPointer());
	QListWidgetItem* ItemName = new QListWidgetItem();
	ItemName->setData(Qt::DisplayRole, QVariant("Name: "+Person->data(0).toString()));
	m_ui.m_personListWidget->insertItem(0, ItemName);
	QListWidgetItem* ItemSurName = new QListWidgetItem();
	ItemSurName->setData(Qt::DisplayRole, QVariant("Sur name: " +Person->data(1).toString()));
	m_ui.m_personListWidget->insertItem(1, ItemSurName);
	QListWidgetItem* ItemAge = new QListWidgetItem();
	ItemAge->setData(Qt::DisplayRole, QVariant("Age: " + Person->data(2).toString()));
	m_ui.m_personListWidget->insertItem(2, ItemAge);
	QListWidgetItem* ItemSex = new QListWidgetItem();
	ItemSex->setData(Qt::DisplayRole, QVariant("Sex: " + Person->data(3).toString()));
	m_ui.m_personListWidget->insertItem(3, ItemSex);
	QListWidgetItem* ItemParent = new QListWidgetItem();
	ItemParent->setData(Qt::DisplayRole, QVariant("Parent: " + Person->data(4).toString()));
	m_ui.m_personListWidget->insertItem(4, ItemParent);
}

void APP_window::exitPersonButtonSlot()
{
	exit(0);
}