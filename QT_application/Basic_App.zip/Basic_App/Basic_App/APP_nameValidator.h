#pragma once
#include <qvalidator.h>

class APP_nameValidator : public QValidator
{
	Q_OBJECT

	public:
		QValidator::State validate(QString& input, int& pos) const override;

};

