#pragma once
#include <QtWidgets/QDialog>
#include "ui_APP_newPerson.h"
#include "APP_nameValidator.h"
#include "APP_ageValidator.h"
#include <QtCore/qdatetime.h>
#include <qmessagebox.h>

class APP_newPerson : public QDialog
{
	Q_OBJECT
protected:
	Ui::APP_newPersonClass m_ui;

public:
	APP_newPerson(QStringList parents, QWidget* parent = Q_NULLPTR);

	QString getName();
	QString getSurName();
	QString getAge();
	QString getSex();
	QString getParent();

protected:
	const APP_nameValidator *m_pNameValidator;
	const APP_ageValidator* m_pAgeValidator;

protected slots:
	void cancelButtonSlot();
	void okButtonSlot();
};

