#include "APP_ageValidator.h"

QValidator::State APP_ageValidator::validate(QString& input, int& pos) const
{
	if (pos == 0) { //avoid erros whit 'delete' when the 'lineEdit' is empty.
		return  Invalid;
	}
	if (input.at(pos - 1).digitValue() != -1) {// no numbers allowed 
		return Acceptable;
	}
	return  Invalid;
}